#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ex08_parsing.h"

/* Pilha de char para os símbolos de abertura */
typedef struct NoChar { char c; struct NoChar *abaixo; } NoChar;
typedef struct { NoChar *topo; } PilhaChar;

static void pc_init(PilhaChar *p)        { p->topo = NULL; }
static int  pc_vazia(const PilhaChar *p) { return p->topo == NULL; }
static void pc_push(PilhaChar *p, char c) {
    NoChar *n = (NoChar *) malloc(sizeof(NoChar));
    n->c = c; n->abaixo = p->topo; p->topo = n;
}
static char pc_pop(PilhaChar *p) {
    NoChar *r = p->topo; char c = r->c;
    p->topo = r->abaixo; free(r); return c;
}

static int corresponde(char aberto, char fechado) {
    return (aberto == '(' && fechado == ')') ||
           (aberto == '[' && fechado == ']') ||
           (aberto == '{' && fechado == '}');
}

/* validar_expressao — O(n)
 * Empilha símbolos de abertura; ao encontrar fechamento,
 * verifica se o topo corresponde. */
int validar_expressao(const char *expr) {
    PilhaChar p;
    pc_init(&p);

    for (int i = 0; expr[i] != '\0'; i++) {
        char c = expr[i];
        if (c == '(' || c == '[' || c == '{') {
            pc_push(&p, c);
        } else if (c == ')' || c == ']' || c == '}') {
            if (pc_vazia(&p) || !corresponde(pc_pop(&p), c)) {
                /* limpa e retorna inválido */
                while (!pc_vazia(&p)) pc_pop(&p);
                return 0;
            }
        }
    }

    int valido = pc_vazia(&p); /* pilha deve estar vazia no final */
    printf("[PARSE] \"%s\" -> %s\n", expr, valido ? "VALIDO" : "INVALIDO");
    return valido;
}
