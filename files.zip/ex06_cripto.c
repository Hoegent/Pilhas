#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ex06_cripto.h"

/* Pilha simples de char (sem alocação dinâmica — char é 1 byte) */
typedef struct NoChar {
    char         c;
    struct NoChar *abaixo;
} NoChar;

typedef struct { NoChar *topo; } PilhaChar;

static void pc_init(PilhaChar *p)              { p->topo = NULL; }
static int  pc_vazia(const PilhaChar *p)       { return p->topo == NULL; }
static void pc_push(PilhaChar *p, char c) {
    NoChar *n = (NoChar *) malloc(sizeof(NoChar));
    n->c = c; n->abaixo = p->topo; p->topo = n;
}
static char pc_pop(PilhaChar *p) {
    NoChar *r = p->topo; char c = r->c;
    p->topo = r->abaixo; free(r); return c;
}

/* criptografia_reversa — O(n)
 * Empilha cada char da palavra; ao encontrar espaço ou fim,
 * desempilha imprimindo os chars em ordem inversa. */
void criptografia_reversa(const char *frase) {
    PilhaChar p;
    pc_init(&p);

    printf("[CRIPTO] Original : %s\n", frase);
    printf("[CRIPTO] Invertido: ");

    for (int i = 0; frase[i] != '\0'; i++) {
        if (frase[i] == ' ') {
            while (!pc_vazia(&p)) printf("%c", pc_pop(&p));
            printf(" ");
        } else {
            pc_push(&p, frase[i]);
        }
    }
    /* última palavra */
    while (!pc_vazia(&p)) printf("%c", pc_pop(&p));
    printf("\n");
}
