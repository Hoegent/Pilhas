#ifndef PILHA_H
#define PILHA_H

#include <stddef.h> /* size_t */

/* Nó interno da pilha encadeada */
typedef struct No {
    char        *dado;     /* string alocada dinamicamente */
    struct No   *abaixo;   /* ponteiro para o nó inferior  */
} No;

/* TAD Pilha (LIFO) */
typedef struct {
    No  *topo;
} Pilha;

/* Inicializa a pilha */
void pilha_inicializar(Pilha *p);

/* Empilha uma cópia da string - O(1) */
int  pilha_push(Pilha *p, const char *valor);

/* Desempilha e copia para destino (deve ter espaço suficiente) - O(1) */
int  pilha_pop(Pilha *p, char *destino, size_t tam);

/* Espia o topo sem remover - O(1) */
const char *pilha_peek(const Pilha *p);

/* Verifica se está vazia - O(1) */
int  pilha_vazia(const Pilha *p);

/* Libera todos os nós - O(n) */
void pilha_destruir(Pilha *p);

#endif
