#include <stdio.h>
#include "ex01_undo.h"

void undo_push(Pilha *p, const char *acao) {
    pilha_push(p, acao);
    printf("[UNDO] Acao registrada: \"%s\"\n", acao);
}

void undo_desfazer(Pilha *p) {
    if (pilha_vazia(p)) {
        printf("[UNDO] Erro: Nao ha acoes para desfazer.\n");
        return;
    }
    char buf[256];
    pilha_pop(p, buf, sizeof(buf));
    printf("[UNDO] Acao desfeita: \"%s\"\n", buf);
}
