#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ex09_ordenacao.h"

/* ordenar_pilha — O(n²)
 * Algoritmo: insertion sort com 1 pilha auxiliar.
 * Para cada elemento retirado de 'p', insere na posição
 * correta em 'aux' (menor no topo), realocando se necessário. */
void ordenar_pilha(Pilha *p) {
    Pilha aux;
    pilha_inicializar(&aux);

    char atual[256], topo_aux[256];

    while (!pilha_vazia(p)) {
        /* Pega o elemento do topo de p */
        pilha_pop(p, atual, sizeof(atual));

        /* Enquanto aux não está vazia e o topo de aux é menor que atual,
         * devolve o topo de aux para p */
        while (!pilha_vazia(&aux) &&
               strcmp(pilha_peek(&aux), atual) < 0) {
            pilha_pop(&aux, topo_aux, sizeof(topo_aux));
            pilha_push(p, topo_aux);
        }

        pilha_push(&aux, atual);
    }

    /* Copia aux de volta para p (inverte para menor ficar no topo) */
    while (!pilha_vazia(&aux)) {
        pilha_pop(&aux, atual, sizeof(atual));
        pilha_push(p, atual);
    }
}
