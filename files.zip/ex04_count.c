#include <stdio.h>
#include "ex04_count.h"

/* pilha_contar — O(n)
 * Não há campo tamanho; percorre os nós via ponteiro abaixo.
 * A pilha permanece intacta (apenas leitura). */
int pilha_contar(const Pilha *p) {
    int count = 0;
    No *atual = p->topo;
    while (atual != NULL) {
        count++;
        atual = atual->abaixo;
    }
    return count;
}
