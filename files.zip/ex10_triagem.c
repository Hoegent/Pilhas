#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ex10_triagem.h"

void pc_chamado_init(PilhaChamado *p)        { p->topo = NULL; }
int  pc_chamado_vazia(const PilhaChamado *p) { return p->topo == NULL; }

int pc_chamado_push(PilhaChamado *p, Chamado c) {
    NoChamado *n = (NoChamado *) malloc(sizeof(NoChamado));
    if (n == NULL) { fprintf(stderr, "[ERRO] malloc falhou.\n"); return 0; }
    n->dado    = c;
    n->abaixo  = p->topo;
    p->topo    = n;
    return 1;
}

int pc_chamado_pop(PilhaChamado *p, Chamado *dest) {
    if (pc_chamado_vazia(p)) return 0;
    NoChamado *r = p->topo;
    if (dest) *dest = r->dado;
    p->topo = r->abaixo;
    free(r);
    return 1;
}

/* triar_chamados — O(n)
 * Usa pilha auxiliar para preservar a ordem original.
 * Etapa 1: desempilha tudo em aux (inverte a ordem).
 * Etapa 2: desempilha aux → urgência 5 vai para prioridade,
 *          demais voltam para original (ordem preservada). */
void triar_chamados(PilhaChamado *original, PilhaChamado *prioridade) {
    PilhaChamado aux;
    pc_chamado_init(&aux);

    Chamado c;

    /* Etapa 1: inverte original em aux */
    while (!pc_chamado_vazia(original)) {
        pc_chamado_pop(original, &c);
        pc_chamado_push(&aux, c);
    }

    /* Etapa 2: filtra */
    while (!pc_chamado_vazia(&aux)) {
        pc_chamado_pop(&aux, &c);
        if (c.urgencia == 5) {
            pc_chamado_push(prioridade, c);
            printf("[TRIAGEM] \"%s\" (urg %d) -> Prioridade Maxima\n",
                   c.nome, c.urgencia);
        } else {
            pc_chamado_push(original, c);
        }
    }
}
