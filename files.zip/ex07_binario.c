#include <stdio.h>
#include <stdlib.h>
#include "ex07_binario.h"

/* Pilha simples de int para os restos */
typedef struct NoInt { int val; struct NoInt *abaixo; } NoInt;
typedef struct { NoInt *topo; } PilhaInt;

static void pi_init(PilhaInt *p)        { p->topo = NULL; }
static int  pi_vazia(const PilhaInt *p) { return p->topo == NULL; }
static void pi_push(PilhaInt *p, int v) {
    NoInt *n = (NoInt *) malloc(sizeof(NoInt));
    n->val = v; n->abaixo = p->topo; p->topo = n;
}
static int pi_pop(PilhaInt *p) {
    NoInt *r = p->topo; int v = r->val;
    p->topo = r->abaixo; free(r); return v;
}

/* converter_binario — O(log n)
 * Empilha restos da divisão por 2; desempilha para formar o binário. */
void converter_binario(int decimal) {
    PilhaInt p;
    pi_init(&p);

    printf("[BIN] Decimal: %d -> Binario: ", decimal);

    if (decimal == 0) { printf("0\n"); return; }

    int n = decimal;
    while (n > 0) {
        pi_push(&p, n % 2);
        n /= 2;
    }

    while (!pi_vazia(&p)) printf("%d", pi_pop(&p));
    printf("\n");
}
