#include <stdio.h>
#include "pilha.h"
#include "ex01_undo.h"
#include "ex02_peek.h"
#include "ex03_clear.h"
#include "ex04_count.h"
#include "ex05_comparison.h"
#include "ex06_cripto.h"
#include "ex07_binario.h"
#include "ex08_parsing.h"
#include "ex09_ordenacao.h"
#include "ex10_triagem.h"

/* Utilitário para imprimir separador */
static void separador(int n, const char *titulo) {
    printf("\n========== EX%02d: %s ==========\n", n, titulo);
}

int main(void) {

    /* ── EX01: Undo ── */
    separador(1, "Undo");
    Pilha undo;
    pilha_inicializar(&undo);
    undo_push(&undo, "digitou 'A'");
    undo_push(&undo, "digitou 'B'");
    undo_push(&undo, "digitou 'C'");
    undo_desfazer(&undo);
    undo_desfazer(&undo);
    undo_desfazer(&undo);
    undo_desfazer(&undo); /* pilha vazia */
    pilha_destruir(&undo);

    /* ── EX02: Peek ── */
    separador(2, "Navegacao (Peek)");
    Pilha nav;
    pilha_inicializar(&nav);
    nav_adicionar(&nav, "https://google.com");
    nav_adicionar(&nav, "https://github.com");
    nav_adicionar(&nav, "https://claude.ai");
    nav_pagina_atual(&nav);
    pilha_destruir(&nav);

    /* ── EX03: Clear ── */
    separador(3, "Clear (Desalocacao)");
    Pilha clr;
    pilha_inicializar(&clr);
    pilha_push(&clr, "processo_A");
    pilha_push(&clr, "processo_B");
    pilha_push(&clr, "processo_C");
    limpar_pilha(&clr);

    /* ── EX04: Count ── */
    separador(4, "Count (Auditoria)");
    Pilha cnt;
    pilha_inicializar(&cnt);
    pilha_push(&cnt, "caixa1");
    pilha_push(&cnt, "caixa2");
    pilha_push(&cnt, "caixa3");
    pilha_push(&cnt, "caixa4");
    printf("[COUNT] Total de elementos: %d\n", pilha_contar(&cnt));
    printf("[COUNT] Pilha intacta: %d elementos\n", pilha_contar(&cnt));
    pilha_destruir(&cnt);

    /* ── EX05: Comparison ── */
    separador(5, "Comparison (Sincronizacao)");
    Pilha sa, sb, sc;
    pilha_inicializar(&sa);
    pilha_inicializar(&sb);
    pilha_inicializar(&sc);
    pilha_push(&sa, "log1"); pilha_push(&sa, "log2"); pilha_push(&sa, "log3");
    pilha_push(&sb, "log1"); pilha_push(&sb, "log2"); pilha_push(&sb, "log3");
    pilha_push(&sc, "log1"); pilha_push(&sc, "log2"); pilha_push(&sc, "logX");
    printf("[COMP] sa == sb? %s\n", pilhas_iguais(&sa, &sb) ? "SIM" : "NAO");
    printf("[COMP] sa == sc? %s\n", pilhas_iguais(&sa, &sc) ? "SIM" : "NAO");
    printf("[COMP] sa ainda tem %d elementos (restaurada)\n", pilha_contar(&sa));
    pilha_destruir(&sa); pilha_destruir(&sb); pilha_destruir(&sc);

    /* ── EX06: Criptografia Reversa ── */
    separador(6, "Criptografia Reversa");
    criptografia_reversa("hello world");
    criptografia_reversa("pilha de dados");

    /* ── EX07: Conversor Binário ── */
    separador(7, "Conversor Binario");
    converter_binario(0);
    converter_binario(10);
    converter_binario(42);
    converter_binario(255);

    /* ── EX08: Parsing ── */
    separador(8, "Validador de Sintaxe");
    validar_expressao("(a + b) * [c - {d}]");
    validar_expressao("{[()]}");
    validar_expressao("(a + [b)");
    validar_expressao("((())");

    /* ── EX09: Ordenação ── */
    separador(9, "Ordenacao (Estacionamento)");
    Pilha ord;
    pilha_inicializar(&ord);
    pilha_push(&ord, "FFF-3333");
    pilha_push(&ord, "AAA-1111");
    pilha_push(&ord, "DDD-4444");
    pilha_push(&ord, "BBB-2222");
    printf("[ORD] Antes: topo=%s\n", pilha_peek(&ord));
    ordenar_pilha(&ord);
    printf("[ORD] Depois (menor no topo): topo=%s\n", pilha_peek(&ord));
    pilha_destruir(&ord);

    /* ── EX10: Triagem ── */
    separador(10, "Triagem de Chamados");
    PilhaChamado original, prioridade;
    pc_chamado_init(&original);
    pc_chamado_init(&prioridade);

    Chamado chamados[] = {
        {"Suporte impressora", 2},
        {"Servidor fora do ar", 5},
        {"Reset de senha",     1},
        {"Queda de rede",      5},
        {"Email lento",        3}
    };
    int n = sizeof(chamados) / sizeof(chamados[0]);
    for (int i = 0; i < n; i++) pc_chamado_push(&original, chamados[i]);

    triar_chamados(&original, &prioridade);

    printf("[TRIAGEM] Pilha original restante:\n");
    Chamado c;
    while (!pc_chamado_vazia(&original)) {
        pc_chamado_pop(&original, &c);
        printf("  - %s (urg %d)\n", c.nome, c.urgencia);
    }
    printf("[TRIAGEM] Pilha Prioridade Maxima:\n");
    while (!pc_chamado_vazia(&prioridade)) {
        pc_chamado_pop(&prioridade, &c);
        printf("  - %s (urg %d)\n", c.nome, c.urgencia);
    }

    return 0;
}
