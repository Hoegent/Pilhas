#include <stdio.h>
#include "ex02_peek.h"

void nav_adicionar(Pilha *p, const char *url) {
    pilha_push(p, url);
    printf("[NAV] Visitando: %s\n", url);
}

void nav_pagina_atual(const Pilha *p) {
    const char *topo = pilha_peek(p);
    if (topo == NULL) {
        printf("[NAV] Historico vazio.\n");
    } else {
        printf("[NAV] Pagina atual: %s\n", topo);
    }
}
