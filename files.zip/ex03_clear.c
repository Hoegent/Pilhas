#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ex03_clear.h"

/* limpar_pilha — O(n)
 * Percorre e libera cada nó individualmente com free().
 * Usa sizeof(No) + strlen(dado)+1 para calcular bytes liberados.
 */
void limpar_pilha(Pilha *p) {
    size_t total = 0;
    while (!pilha_vazia(p)) {
        No *removido = p->topo;
        total += sizeof(No) + strlen(removido->dado) + 1;
        p->topo = removido->abaixo;
        free(removido->dado);
        free(removido);
    }
    printf("[CLEAR] Memoria liberada: %zu bytes.\n", total);
}
