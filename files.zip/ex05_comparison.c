#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ex05_comparison.h"

/* pilhas_iguais — O(n)
 * Usa duas pilhas auxiliares para restaurar a ordem original
 * após a comparação. */
int pilhas_iguais(Pilha *a, Pilha *b) {
    Pilha aux_a, aux_b;
    pilha_inicializar(&aux_a);
    pilha_inicializar(&aux_b);

    int iguais = 1;
    char buf_a[256], buf_b[256];

    /* Desempilha comparando elemento a elemento */
    while (!pilha_vazia(a) && !pilha_vazia(b)) {
        pilha_pop(a, buf_a, sizeof(buf_a));
        pilha_pop(b, buf_b, sizeof(buf_b));
        pilha_push(&aux_a, buf_a);
        pilha_push(&aux_b, buf_b);
        if (strcmp(buf_a, buf_b) != 0) {
            iguais = 0;
        }
    }

    /* Se uma ainda tem elementos, tamanhos diferentes */
    if (!pilha_vazia(a) || !pilha_vazia(b)) iguais = 0;

    /* Restaura a e b */
    while (!pilha_vazia(&aux_a)) {
        pilha_pop(&aux_a, buf_a, sizeof(buf_a));
        pilha_push(a, buf_a);
    }
    while (!pilha_vazia(&aux_b)) {
        pilha_pop(&aux_b, buf_b, sizeof(buf_b));
        pilha_push(b, buf_b);
    }

    return iguais;
}
