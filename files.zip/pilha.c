#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pilha.h"

void pilha_inicializar(Pilha *p) {
    p->topo = NULL;
}

/* push — O(1): aloca nó + cópia da string, encadeia no topo */
int pilha_push(Pilha *p, const char *valor) {
    No *novo = (No *) malloc(sizeof(No));
    if (novo == NULL) {
        fprintf(stderr, "[ERRO] Falha ao alocar no.\n");
        return 0;
    }

    novo->dado = (char *) malloc(strlen(valor) + 1);
    if (novo->dado == NULL) {
        fprintf(stderr, "[ERRO] Falha ao alocar string.\n");
        free(novo);
        return 0;
    }

    strcpy(novo->dado, valor);
    novo->abaixo = p->topo;
    p->topo      = novo;
    return 1;
}

/* pop — O(1): remove topo, copia dado, libera nó */
int pilha_pop(Pilha *p, char *destino, size_t tam) {
    if (pilha_vazia(p)) {
        fprintf(stderr, "[AVISO] Pilha vazia, nada a desempilhar.\n");
        return 0;
    }

    No *removido = p->topo;
    if (destino != NULL) {
        strncpy(destino, removido->dado, tam - 1);
        destino[tam - 1] = '\0';
    }

    p->topo = removido->abaixo;
    free(removido->dado);
    free(removido);
    return 1;
}

/* peek — O(1): acesso direto ao topo */
const char *pilha_peek(const Pilha *p) {
    if (pilha_vazia(p)) return NULL;
    return p->topo->dado;
}

/* vazia — O(1) */
int pilha_vazia(const Pilha *p) {
    return p->topo == NULL;
}

/* destruir — O(n): libera todos os nós */
void pilha_destruir(Pilha *p) {
    while (!pilha_vazia(p)) {
        pilha_pop(p, NULL, 0);
    }
}
